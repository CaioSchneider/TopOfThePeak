/*using UnityEngine;
using UnityEngine.UI;

public class ScreenFilter : MonoBehaviour
{
    public static Image filterImage; // arraste a Image aqui no Inspector
    private void Start()
    {
        filterImage.enabled = false;
    }
    // Ativa o filtro com a cor definida
    public void SetFilter()//Color color
    {
       // filterImage.color = color;
        filterImage.enabled = true;
    }

    // Desativa o filtro
    public void ClearFilter()
    {

        filterImage.enabled = false;
    }
}
*/